package web.maths.data;

public enum Role {
    USER, ADMIN;
}
