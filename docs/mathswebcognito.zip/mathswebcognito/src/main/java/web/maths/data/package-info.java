@NonNullApi
package web.maths.data;

import org.springframework.lang.NonNullApi;
